# retefe
Artefacts from various retefe campaigns


## Sources
### Potential sources for various methods/funtions
1. QuasarRAT/Client/Core/Recovery/Browsers/Firefox.cs
  * https://github.com/quasar/QuasarRAT/blob/master/Client/Core/Recovery/Browsers/Firefox.cs
2. Pastebin: Firefox 37+ Password & Cookie Recovery
  * http://pastebin.com/Qzctxjet
3. PowerShell Code Repository: Using Task Sch, wrapper by BattleChicken
  * http://poshcode.org/5805
4. Получить handle дочернего окна - C#
  * http://www.cyberforum.ru/csharp-net/thread656891.html
